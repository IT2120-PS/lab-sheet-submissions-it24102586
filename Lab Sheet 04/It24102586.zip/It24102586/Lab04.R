setwd("C:\\Users\\it24102586\\Desktop\\It24102586")

branch_data<-read.table("Exercise.txt",header=TRUE, sep=",")
fix(branch_data)

head(branch_data)
sapply(branch_data, class)

boxplot(branch_data$Sales_X1,main="Box plot for sales",outline=TRUE,outpch=8,horizontal=TRUE)

print(fivenum(branch_data$Advertising_X2))
IQR(branch_data$Advertising_X2)


find_outliers <- function(z){
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3-q1
  
  ub <- q3 + 1.5*iqr
  lb <- q1 - 1.5*iqr
  
  print(paste("outliers:",paste(sort(z[z<lb] | z>ub]),collapse =",")))
}
get.outliers(branch_data$Years_X3)